Experiment - 2

## Learning Outcomes
1. Understanding and creating functional React components.
2. Implementing a client-side routing using React Router.
3. Managing component state and lifecycle in a React application.
4. Structuring a React project with components, assets, and styles.

