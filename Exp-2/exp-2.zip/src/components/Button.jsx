import Button from '@mui/material/Button';

export default function ButtonBasic() {
  return (
    <Button size="small" variant='outlined'>Small</Button>
  );
}