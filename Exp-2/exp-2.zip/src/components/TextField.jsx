import React from 'react';

function TextField() {
  return (
    <div>
      <input type="text" placeholder="Text Field" />
    </div>
  );
}

export default TextField;
