export default function Contact(){
    return <h2> Contact here </h2>
}